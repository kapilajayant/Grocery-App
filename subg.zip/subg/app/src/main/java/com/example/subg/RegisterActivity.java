package com.example.subg;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {


    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firebaseFirestore;
    EditText et_name, et_phone, et_email, et_password, et_confirm;
    Button btn_register;
    ProgressDialog progress;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        et_email = (EditText)findViewById(R.id.et_email);
        et_password = (EditText)findViewById(R.id.et_password);
        et_confirm = (EditText)findViewById(R.id.et_confirm);
        btn_register = (Button)findViewById(R.id.btn_register);
        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkinputs();
            }
        });
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();

    }

    private void checkinputs() {

        if(!TextUtils.isEmpty(et_email.getText().toString()))
        {
            if (!TextUtils.isEmpty(et_password.getText().toString()))
            {
                if(!TextUtils.isEmpty(et_confirm.getText().toString()))
                {
                    if ((et_confirm.getText().toString().equals(et_password.getText().toString()))) {
                        CreateAccount();
                    }
                    else {
                        et_confirm.setError("Doesn't Match with Password");
                        Toast.makeText(getApplicationContext(), "Enter same password in both fields", Toast.LENGTH_SHORT).show();
                    }

                }
                else
                {
                    et_confirm.setError("Empty Field!");
                    Toast.makeText(getApplicationContext(), "Please Confirm Your Password", Toast.LENGTH_SHORT).show();
                }
            }
            else
            {
                et_password.setError("Password Cannot Be Empty");
                Toast.makeText(getApplicationContext(), "Please Enter Your Password", Toast.LENGTH_SHORT).show();
            }
        }
        else
        {
            et_email.setError("Email Cannot Be Empty");
            Toast.makeText(getApplicationContext(), "Please Fill Your Email", Toast.LENGTH_SHORT).show();
        }

    }

    private void CreateAccount() {
        String email = et_email.getText().toString();
        String password = et_password.getText().toString();
        final String name = et_name.getText().toString();
        final String phone = et_phone.getText().toString();
        progress = new ProgressDialog(this);
        progress.setTitle("Creating Account...");
        progress.setMessage("Please Wait!");
        progress.setCancelable(true);
        progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progress.show();
        progress.closeOptionsMenu();
        firebaseAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    Map<Object, String> userdata = new HashMap<>();
                    userdata.put("fullname",name);
                    userdata.put("phone",phone);

                    firebaseFirestore.collection("Users").add(userdata).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                        @Override
                        public void onComplete(@androidx.annotation.NonNull Task<DocumentReference> task) {
                            if(task.isSuccessful())
                            {
                                Intent mainIntent = new Intent(RegisterActivity.this, MainActivity.class);
                                startActivity(mainIntent);
                                finish();
                            }
                            else
                            {
                                String error = task.getException().getMessage();
                                Toast.makeText(getApplicationContext(), error, Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                }
                else
                {
                    String error = task.getException().getMessage();
                    Toast.makeText(getApplicationContext(), error, Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    public void SignInActivity(View view) {
        startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
        finish();
    }
}
